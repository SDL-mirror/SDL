SDL/MacOS X Project Builder Notes

About:
	Enclosed are project files for building the SDL library, SDL tests, and project stationary for SDL applications. These are intended for use on   SDL 1.2.3 or later, MacOS 10.1 with Project Builder 1.1 (v.73.3). Older versions may not work correctly. See README.MacOS X for further information.

Project Notes:
  I. Project Stationary
      a) To install, copy the files to their indicated locations.
      b) Use like any other stationary ("New Project" or "New Target")

  II. SDL Framework
      a) The framework bundle is copied to ~/Library/Frameworks after build
      b) You can move it somewhere else if you like.
      c) You may want to prebind it for better performance, using the
          "update_prebinding" shell command.
      d) The code is built in debug mode currently, optimize it by
          changing the "Build Style" to "Deployment", clean, and rebuild

  III. SDL Tests
      a) You can specify arguments using the "Executables" panel of the
          target.
      b) You may have to move things around if a test opens up files.
          1. The working directory of a SDL app is set to its parent.
  
  IV.  SDL Distro Installer Builders
      a) The Standard Package contains only a Framework and is installed
         into /Library/Frameworks
      b) The Devel Package contains everything you should need to start
         writing a SDL app. This includes API docs and project stationary.

Things to try:
  I.   Setup the integrated CVS features in the IDE for SDL.
  II.  Contribute code for improving the implementation!
  III. Port a game to SDL/MacOS X!
  IV.  Send complaints to SDL mailing list, IRC channel, or me!

Contact Info:
	These Project Builder files are maintained primarily by me, Darrell Walisser <dwaliss1@purdue.edu>. Please send all questions/comments to the sdl mailing list <sdl@libsdl.org> so that others may help where they can.
