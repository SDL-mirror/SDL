SDL/MacOS X Developer Notes

About:
	The initial port to MacOS X has been coded by me, Darrell Walisser <dwaliss1@purdue.edu>. I started thinking about this port way back in December '00; it finally came to life in mid April '01, inspired by the excellent presentation and source code by the OmniGroup <www.omnigroup.com> on porting games to MacOS X. Without their instruction, this would have taken much longer! Thanks! For information on code status, innards, and bugs I know about, see the source code in src/video/quartz and src/main/macosx, bug list in BUGS and errata in README.MacOSX.

Project Notes:
  I. Project Stationary
      a) To install, copy the files to their indicated locations.
      b) Use like any other stationary ("New Project" or "New Target")
      c) The "Target" stationary is halfway implemented,
          after creating a new target, to the 'Application Settings' panel
             1. Enter the "Executable" name (same as target name helps)
             2. Enter "NSApplication" as the "Principal class"
             3. Enter "SDLMain.nib" as the "Main nib file"
  II. SDL Framework
      a) The framework bundle is copied to ~/Library/Frameworks after build
      b) You can move it somewhere else if you like.
      c) You may want to prebind it for better performance, using the
          "update_prebinding" shell command.
      d) The code is built in debug mode currently, optimize it by
          changing the "Build Style" to "Deployment", clean, and rebuild

  III. SDL Tests
      a) You can specify arguments using the "Executables" panel of the
          target.
      b) You may have to move things around if a test opens up files.
          1. The working directory of a SDL app is set to its parent.
  
  IV.  SDL Distro Installer Builders
      a) The Standard Package contains only a Framework and is installed
         into /Library/Frameworks
      b) The Devel Package contains everything you should need to start
         writing a SDL app. This includes API docs and project stationary.

Things to try:
  I.   Setup the integrated CVS features in the IDE for SDL.
  II.  Contribute code for improving the implementation!
  III. Port a game to SDL/MacOS X!
  IV.  Send complaints to SDL mailing list, IRC channel, or me!
  V.   Figure out how to build a Cocoa app from scratch using makefile.

Thanks,
Darrell Walisser (dwaliss1@purdue.edu)
      
