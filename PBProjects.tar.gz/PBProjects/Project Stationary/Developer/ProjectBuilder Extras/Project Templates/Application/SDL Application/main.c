/*
 *  main.c
 *  SDL Application
 *  
 */

#include "SDL.h"

int main (int argc, char** argv) {

    /* Initialize SDL */
    if ( SDL_Init(SDL_INIT_VIDEO) < 0 ) {
        fprintf(stderr, "Couldn't initialize SDL:%s\n",SDL_GetError());
		exit(1);
    }

    /*
     * Add your code here...
     */
    
    SDL_Quit();
    return(0);
}

