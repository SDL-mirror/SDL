#import <Cocoa/Cocoa.h>

@interface SDLMain : NSObject
{
}
- (IBAction)quit:(id)sender;
@end
