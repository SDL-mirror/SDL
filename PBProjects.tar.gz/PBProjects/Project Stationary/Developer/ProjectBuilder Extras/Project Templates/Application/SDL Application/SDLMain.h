#import <Cocoa/Cocoa.h>

@interface SDLMain : NSObject
{
}
- (IBAction)quit:(id)sender;
- (IBAction)makeFullscreen:(id)sender;
@end
