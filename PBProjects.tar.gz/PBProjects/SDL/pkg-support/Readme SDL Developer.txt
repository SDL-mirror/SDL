SDL MacOS X Developer Notes:
    This note contains brief information that should get you up and running quickly. For more complete documentation, please see READMEs included with the SDL source code. Also, don't forget about the API documentation in /Developer/Documentation/SDL and man pages.

How to create a new SDL project:

    1. Open Project Builder
    2. Select File->New Project
    3. Select SDL Application
    4. Save, and Finish
    5. Add your sources.
    6. That's it!

What was installed and where:
    SDL.framework in ~/Library/Frameworks (includes Binary and Headers)
    Project Stationary in /Developer/ProjectBuilder Extras
    Man pages in /Developer/Documentation/ManPages/man3
    HTML documentation in /Developer/Documentation/SDL
    This README in your home directory.
    Package receipt in /Library/Receipts/SDL-devel.pkg
    
What was not installed (Available in the SDL source code):
    - configure/make support.
    - SDL library source code and Framework Projects.
    
Project Builder Tips and Tricks:

- Using the Project Stationary
    Copy the stationary to the indicated folders to access it from
    the "File->New Project" and "Project->New Target" menus.
    
- Building from command line
    Use pbxbuild in the same directory as your .pbproj file
         
- Running your app
    You can send command line args to your app by either invoking it from
    the command line (in *.app/Contents/MacOS) or by entering them in the
    "Executibles" panel of the target settings.
    
Implementation Notes:

    Some things that may be of interest about how it all works...
    * Working directory
        As defined in the SDLMain.m file, the working directory of 
	your SDL app is by default set to its parent. You may wish to 
	change this to better suit your needs.

See BUGS in the SDL source code for current bugs in the implementation.