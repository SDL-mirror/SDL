SDL MacOS X Developer Notes:
    This note contains brief information that should get you up and running quickly. For more complete documentation, please see READMEs included with the SDL source code. Also, don't forget about the API documentation in /Developer/Documentation/SDL and man pages.

How to create a new SDL project:

    1. Open Project Builder
    2. Select File->New Project
    3. Select SDL Application
    4. Save, and Finish
    5. Add your sources.
    6. Thats it!

What was installed and where:
    SDL.framework in ~/Library/Frameworks (includes Binary and Headers)
    Project Stationary in /Developer/ProjectBuilder Extras
    Man pages in /Developer/Documentation/ManPages/man3
    HTML documentation in /Developer/Documentation/SDL
    This README in your home directory.
    Package receipt in /Library/Receipts/SDL-devel.pkg
    
What was not installed:
    Makefile/configure support for your app (we're working on it!).
    SDL library source code and Framework Projects for Project Builder.

Project Builder Tips and Tricks:

- Using the Project Stationary
    Copy the stationary to the indicated folders to access it from
    the "New Project" and "Add target" menus. What could be easier?
    
- Building from command line
    Use pbxbuild in the same directory as your .pbproj file
         
- Running your app
    You can send command line args to your app by either invoking it from
    the command line (in *.app/Contents/MacOS) or by entering them in the
    "Executibles" panel of the target settings.
    
Implementation Notes:

    Some things that may be of interest about how it all works...
    * Working directory
        As defined in the SDLMain.m file, the working directory of 
	your SDL app is by default set to its parent. You may wish to 
	change this to better suit your needs.
        
BUGS:
	Joystick and CD-ROM functions are not implemented yet.

	Window management buttons don't draw correctly.

	Window may not close when unsetting video mode and resetting.

	Resizeable windows aren't implemented yet.

	Depth switching for windowed mode isn't implemented yet.
	
	Palette handling isn't implemented in windowed mode yet.
	
	Command-line arguments Dialog is not implemented yet.

	Fullscreen drawing has some artifacts.
	
	Fullscreen window covers *all* other windows - even force quit.
	
	Fullscreen OpenGL for the software renderer is broken.

	Some OpenGL parameters are not accounted for, for example color bits customization.
	
	Getting OpenGL context parameters is not implemented.
	
	Continuous mouse motion perhaps is not as smooth as it should be.

	SDL_WM_GrabInput() is implemented, but it "freezes" the hardware
	cursor in the center of the window/screen.  Also, mouse moved events
	are not generated, and the keyboard cannot be grabbed.

	Not all of the keys are properly recognized on the keyboard.

	MacOS X seems to have a broken pthread_cancel() implementation.


    