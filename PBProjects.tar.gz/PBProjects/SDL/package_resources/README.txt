Package resources

Here I've tried to put together a set of resources suitable for using PackageBuilder to distribute the SDL libraries.

This is a work in progress, eventually should work quit well for distributing SDL and related libraries.